//
//  UKDebugNames.h
//  filebrowser
//
//  Created by Uli Kusterer on 01.05.05.
//  Copyright 2005 M. Uli Kusterer. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*
    This is a handy debugging aid for printf-style debugging (i.e. if you're
    using NSLog statements to track down bugs). This assigns each object a
    human-readable name (from a list of predefined names it has) which are much
    easier to distinguish than 0x00488010-style numbers.
*/

NSString*   UKDebugNameFor( id obj );
